import { useState, useEffect } from "react";
import {
  Phone,
  MapPin,
  Clock,
  Menu as MenuIcon,
  X,
  UtensilsCrossed,
  Coffee,
  ChevronRight,
  Star,
} from "lucide-react";

/* Inline social icons to avoid version mismatches */
const Instagram = ({ size = 18 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
    <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
  </svg>
);
const Facebook = ({ size = 18 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
  </svg>
);

/* ---------------- NAVBAR ---------------- */
function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const links = [
    { href: "#accueil", label: "Accueil" },
    { href: "#ambiance", label: "Ambiance" },
    { href: "#infos", label: "Infos pratiques" },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-warm-950/90 backdrop-blur-md shadow-lg py-3"
          : "bg-transparent py-5"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        <a href="#accueil" className="flex flex-col leading-tight">
          <span
            className={`font-serif font-bold text-xl sm:text-2xl tracking-wide transition-colors ${
              scrolled ? "text-warm-100" : "text-white text-shadow"
            }`}
          >
            MA LOUNGE
          </span>
          <span className="font-script text-gold text-sm sm:text-base -mt-1">
            le coin du bonheur
          </span>
        </a>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-8">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className={`text-sm font-medium tracking-wide transition-colors hover:text-gold ${
                scrolled ? "text-warm-100" : "text-white text-shadow"
              }`}
            >
              {l.label}
            </a>
          ))}
          <a
            href="tel:+2250505555627"
            className="flex items-center gap-2 bg-gold hover:bg-warm-600 text-warm-950 hover:text-white px-5 py-2 rounded-full text-sm font-semibold transition-all shadow-md hover:shadow-lg"
          >
            <Phone size={16} /> Réserver
          </a>
        </nav>

        {/* Mobile button */}
        <button
          onClick={() => setOpen(!open)}
          className={`md:hidden p-2 rounded-md ${
            scrolled ? "text-warm-100" : "text-white"
          }`}
          aria-label="Menu"
        >
          {open ? <X size={24} /> : <MenuIcon size={24} />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden bg-warm-950/95 backdrop-blur-md border-t border-warm-800 mt-3">
          <nav className="flex flex-col px-4 py-4 gap-3">
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className="text-warm-100 hover:text-gold py-2 font-medium"
              >
                {l.label}
              </a>
            ))}
            <a
              href="tel:+2250505555627"
              className="flex items-center justify-center gap-2 bg-gold text-warm-950 px-5 py-3 rounded-full font-semibold mt-2"
            >
              <Phone size={16} /> 05 05 55 56 27
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}

/* ---------------- HERO ---------------- */
function Hero() {
  return (
    <section
      id="accueil"
      className="relative min-h-screen flex items-center justify-center bg-grain overflow-hidden"
    >
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: "url(/images/hero.jpg)" }}
      />
      {/* Dark warm gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-warm-950/70 via-warm-950/50 to-warm-950/90" />
      {/* Decorative vignette */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_30%,rgba(0,0,0,0.6))]" />

      <div className="relative z-10 text-center px-4 sm:px-6 max-w-4xl mx-auto">
        <div className="animate-fade-in-up">
          <p className="font-script text-gold text-xl sm:text-2xl mb-3 tracking-wide">
            Bienvenue au
          </p>
          <h1 className="font-serif font-bold text-4xl sm:text-6xl lg:text-7xl text-white mb-3 leading-tight text-shadow-lg">
            MA LOUNGE
            <br />
            <span className="font-serif text-2xl sm:text-3xl lg:text-4xl text-warm-200 font-normal italic">
              Restaurant
            </span>
          </h1>
          <p className="font-script text-gold text-2xl sm:text-3xl mb-8">
            le coin du bonheur
          </p>
        </div>
        <p className="animate-fade-in-up-delay-1 text-warm-100 text-base sm:text-lg max-w-2xl mx-auto mb-10 leading-relaxed text-shadow">
          Un espace chic et convivial où la gastronomie rencontre la douceur de
          vivre. Bois chaleureux, lumières tamisées et saveurs authentiques vous
          attendent à Songon-Kassemblé.
        </p>
        <div className="animate-fade-in-up-delay-2 flex flex-col sm:flex-row gap-4 justify-center">
          <a
            href="tel:+2250505555627"
            className="inline-flex items-center justify-center gap-2 bg-gold hover:bg-warm-500 text-warm-950 px-8 py-4 rounded-full text-lg font-semibold transition-all shadow-xl hover:shadow-2xl hover:-translate-y-0.5"
          >
            <Phone size={20} /> Réserver une table
          </a>
          <a
            href="#ambiance"
            className="inline-flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 backdrop-blur-sm border border-white/30 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all"
          >
            Découvrir le lieu
            <ChevronRight size={20} />
          </a>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-7 h-11 border-2 border-white/50 rounded-full flex justify-center pt-2">
          <div className="w-1.5 h-3 bg-white/70 rounded-full" />
        </div>
      </div>
    </section>
  );
}

/* ---------------- ABOUT / AMBIANCE ---------------- */
function About() {
  return (
    <section id="ambiance" className="py-20 sm:py-28 bg-cream relative">
      {/* Decorative top border */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-gold to-transparent opacity-40" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <p className="font-script text-warm-600 text-2xl mb-2">
            Venez comme vous êtes
          </p>
          <h2 className="font-serif text-4xl sm:text-5xl font-bold text-warm-900 mb-4">
            L'Ambiance Lounge
          </h2>
          <div className="w-20 h-1 bg-gold mx-auto rounded-full" />
        </div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Text */}
          <div className="space-y-6 order-2 lg:order-1">
            <h3 className="font-serif text-2xl sm:text-3xl font-semibold text-warm-900 leading-snug">
              Un havre de paix où confort et convivialité se rencontrent.
            </h3>
            <p className="text-warm-800 text-lg leading-relaxed">
              Niché au cœur de Songon-Kassemblé, <strong>MA Lounge</strong> est
              bien plus qu'un restaurant : c'est un véritable coin de bonheur.
              Nos banquettes moelleuses en velours, nos séparateurs en bois
              brut et nos éclairages tamisés créent une atmosphère intime et
              chaleureuse, idéale pour un repas en amoureux, un brunch en
              famille ou un verre entre amis.
            </p>
            <p className="text-warm-800 text-lg leading-relaxed">
              Laissez-vous envoûter par notre coin musique, nos plantes
              décoratives qui apportent une touche de fraîcheur, et notre bar
              en bois où nos mixologues préparent des cocktails aussi beaux que
              bons. Chaque détail a été pensé pour que vous vous sentiez comme
              chez vous — mais en mieux.
            </p>

            <div className="grid grid-cols-3 gap-4 pt-6">
              <div className="text-center p-4 rounded-xl bg-white shadow-sm border border-warm-200">
                <div className="text-gold mb-1 flex justify-center">
                  <Star size={24} fill="currentColor" />
                </div>
                <p className="text-sm text-warm-700 font-medium">
                  Cuisine raffinée
                </p>
              </div>
              <div className="text-center p-4 rounded-xl bg-white shadow-sm border border-warm-200">
                <div className="text-gold mb-1 flex justify-center">
                  <Coffee size={24} />
                </div>
                <p className="text-sm text-warm-700 font-medium">
                  Du p'tit dej' au dîner
                </p>
              </div>
              <div className="text-center p-4 rounded-xl bg-white shadow-sm border border-warm-200">
                <div className="text-gold mb-1 flex justify-center">
                  <UtensilsCrossed size={24} />
                </div>
                <p className="text-sm text-warm-700 font-medium">
                  Ambiance conviviale
                </p>
              </div>
            </div>
          </div>

          {/* Images collage */}
          <div className="order-1 lg:order-2 grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <div className="rounded-2xl overflow-hidden shadow-xl aspect-[3/4] group">
                <img
                  src="/images/banquettes.jpg"
                  alt="Banquettes confortables"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
              </div>
              <div className="rounded-2xl overflow-hidden shadow-xl aspect-square group">
                <img
                  src="/images/lounge-yellow.jpg"
                  alt="Salon lounge jaune"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
              </div>
            </div>
            <div className="space-y-4 pt-8">
              <div className="rounded-2xl overflow-hidden shadow-xl aspect-square group">
                <img
                  src="/images/bar.jpg"
                  alt="Le bar en bois"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
              </div>
              <div className="rounded-2xl overflow-hidden shadow-xl aspect-[3/4] group relative bg-warm-900 flex items-center justify-center">
                <img
                  src="/images/fish-dish.jpg"
                  alt="Plat signature"
                  className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 flex items-center justify-center bg-warm-950/40">
                  <p className="font-script text-white text-3xl text-shadow">
                    Notre coin musique
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- INFOS PRATIQUES ---------------- */
function InfoPratique() {
  const horaires = [
    { jours: "Lundi — Jeudi", heures: "07h00 — 22h00" },
    { jours: "Vendredi — Samedi", heures: "07h00 — 00h00" },
    { jours: "Dimanche", heures: "07h00 — 23h00" },
  ];

  return (
    <section id="infos" className="py-20 sm:py-28 bg-cream relative">
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-gold to-transparent opacity-40" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-14">
          <p className="font-script text-warm-600 text-2xl mb-2">Venez nous voir</p>
          <h2 className="font-serif text-4xl sm:text-5xl font-bold text-warm-900 mb-4">
            Infos Pratiques
          </h2>
          <div className="w-20 h-1 bg-gold mx-auto rounded-full" />
        </div>

        <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
          {/* Horaires */}
          <div className="bg-white rounded-2xl shadow-lg p-8 border-t-4 border-gold hover:shadow-xl transition-shadow">
            <div className="w-14 h-14 rounded-full bg-gold/15 flex items-center justify-center mb-5">
              <Clock size={28} className="text-warm-700" />
            </div>
            <h3 className="font-serif text-2xl font-bold text-warm-900 mb-5">
              Horaires
            </h3>
            <ul className="space-y-4">
              {horaires.map((h) => (
                <li key={h.jours} className="flex justify-between items-start gap-2">
                  <span className="font-medium text-warm-800">{h.jours}</span>
                  <span className="text-warm-600 text-right font-serif">
                    {h.heures}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          {/* Adresse */}
          <div className="bg-white rounded-2xl shadow-lg p-8 border-t-4 border-gold hover:shadow-xl transition-shadow">
            <div className="w-14 h-14 rounded-full bg-gold/15 flex items-center justify-center mb-5">
              <MapPin size={28} className="text-warm-700" />
            </div>
            <h3 className="font-serif text-2xl font-bold text-warm-900 mb-5">
              Adresse
            </h3>
            <p className="text-warm-800 text-lg leading-relaxed mb-4">
              MA Lounge Restaurant
              <br />
              Songon-Kassemblé
              <br />
              Côte d'Ivoire
            </p>
            <a
              href="https://www.google.com/maps/search/?api=1&query=Songon-Kassemblé"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-gold hover:text-warm-700 font-semibold transition-colors"
            >
              Itinéraire <ChevronRight size={18} />
            </a>
          </div>

          {/* Contact / Réservation */}
          <div className="bg-warm-900 rounded-2xl shadow-lg p-8 text-warm-100 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-gold/10 rounded-full -translate-y-10 translate-x-10" />
            <div className="relative">
              <div className="w-14 h-14 rounded-full bg-gold/20 flex items-center justify-center mb-5">
                <Phone size={28} className="text-gold" />
              </div>
              <h3 className="font-serif text-2xl font-bold text-white mb-5">
                Réservation
              </h3>
              <p className="text-warm-200 leading-relaxed mb-5">
                Pour réserver votre table ou pour toute demande, n'hésitez pas à
                nous appeler.
              </p>
              <a
                href="tel:+2250505555627"
                className="inline-flex items-center gap-3 bg-gold hover:bg-warm-500 text-warm-950 px-5 py-3 rounded-full font-bold transition-all shadow-lg w-full justify-center"
              >
                <Phone size={20} />
                05 05 55 56 27
              </a>
              <p className="text-warm-300 text-sm mt-4 text-center">
                Appel et WhatsApp
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- FOOTER ---------------- */
function Footer() {
  return (
    <footer className="bg-warm-950 text-warm-200 pt-16 pb-8 relative">
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-gold to-transparent opacity-40" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-3 gap-10 mb-10">
          <div>
            <h4 className="font-serif font-bold text-2xl text-white mb-1">
              MA LOUNGE
            </h4>
            <p className="font-script text-gold text-lg mb-4">
              le coin du bonheur
            </p>
            <p className="text-warm-300 text-sm leading-relaxed">
              Un restaurant lounge chaleureux à Songon-Kassemblé où saveurs,
              confort et convivialité vous attendent du petit-déjeuner au
              dîner.
            </p>
          </div>

          <div>
            <h5 className="font-serif font-bold text-lg text-white mb-4">
              Navigation
            </h5>
            <ul className="space-y-2 text-sm">
              <li><a href="#accueil" className="hover:text-gold transition-colors">Accueil</a></li>
              <li><a href="#ambiance" className="hover:text-gold transition-colors">Notre ambiance</a></li>

              <li><a href="#infos" className="hover:text-gold transition-colors">Infos pratiques</a></li>
            </ul>
          </div>

          <div>
            <h5 className="font-serif font-bold text-lg text-white mb-4">
              Suivez-nous
            </h5>
            <p className="text-warm-300 text-sm mb-4">
              Découvrez nos plats et notre actualité sur les réseaux sociaux.
            </p>
            <div className="flex gap-3">
              <a
                href="#"
                className="w-10 h-10 rounded-full bg-warm-800 hover:bg-gold hover:text-warm-950 text-warm-200 flex items-center justify-center transition-all"
                aria-label="Instagram"
              >
                <Instagram size={18} />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full bg-warm-800 hover:bg-gold hover:text-warm-950 text-warm-200 flex items-center justify-center transition-all"
                aria-label="Facebook"
              >
                <Facebook size={18} />
              </a>
              <a
                href="tel:+2250505555627"
                className="w-10 h-10 rounded-full bg-warm-800 hover:bg-gold hover:text-warm-950 text-warm-200 flex items-center justify-center transition-all"
                aria-label="Téléphone"
              >
                <Phone size={18} />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-warm-800 pt-6 flex flex-col sm:flex-row justify-between items-center gap-3 text-sm text-warm-400">
          <p>© {new Date().getFullYear()} MA Lounge Restaurant. Tous droits réservés.</p>
          <p className="font-script text-gold text-base">
            Fait avec passion au coin du bonheur
          </p>
        </div>
      </div>
    </footer>
  );
}

/* ---------------- APP ---------------- */
export default function App() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main>
        <Hero />
        <About />

        <InfoPratique />
      </main>
      <Footer />
    </div>
  );
}
